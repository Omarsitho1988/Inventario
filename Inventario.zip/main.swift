import Glibc

struct Colors {
    static let reset = "\u{001B}[0;0m"
    static let black = "\u{001B}[0;30m"
    static let red = "\u{001B}[0;31m"
    static let green = "\u{001B}[0;32m"
    static let yellow = "\u{001B}[0;33m"
    static let blue = "\u{001B}[0;34m"
    static let magenta = "\u{001B}[0;35m"
    static let cyan = "\u{001B}[0;36m"
    static let white = "\u{001B}[0;37m"
}

class Articulo{
  var nombre : String
  var cantidad : Int

  init (nombre: String,cantidad : Int) {
        self.nombre = nombre
        self.cantidad = cantidad
    }
}

var Inventario = [Articulo]()

func optionsMenu(){

  let opcion = readLine()

  switch(opcion){
    case "1" : 
        Glibc.system("clear");verInventario(); break;
    case "2" : 
        Glibc.system("clear");agregarInventario(); break;
    case "3" : 
        Glibc.system("clear");consultarInventario(); break;
    case "0" : 
        Glibc.system("clear");menu(); break;
    default : 
        print("Opción no válida");optionsMenu();break;
  }
  
}

func menu(){

  print(Colors.blue+"Ingrese el número de su opción :")
  print("1 . Ver Inventario")
  print("2 . Agregar Articulo")
  print("3 . Consultar Articulo")
  print("0 . Salir al menu principal")

  optionsMenu()
  
}

func verInventario(){

    print(Colors.green+"------LISTA DE ARTICULOS------");

    for articulo in Inventario {
        print(Colors.green+articulo.nombre + ":" + Colors.yellow+String(articulo.cantidad))
    }
                     
    optionsMenu()
}
func agregarInventario(){

  print("Ingrese la cantidad")

  let cantidad = Int(readLine()!) ?? 0

  print("Ingrese Nombre")

  let nombre = readLine();
  
Inventario.append(Articulo(nombre:nombre!,cantidad:cantidad))
  Glibc.system("clear")

  print("Articulo agregado presione 0 para volver al menu inicial")

  optionsMenu()
  
}
func consultarInventario(){

  print(Colors.cyan + "Ingrese nombre del articulo o 0 para regresar al menu principal")

  let nombre = readLine();

  switch(nombre){
    case "0" : menu();break;
    default : 
    var enInventario = 0
    for articulo in Inventario {
      if(articulo.nombre==nombre){
        enInventario = 1
        print(Colors.magenta + "Las piezas que quedan :" + Colors.yellow+String(articulo.cantidad))
      }

      }
      
      if(enInventario==0){
        print(Colors.red + "El articulo no existe")
      }

      consultarInventario();

      break;
    
  }
  
}

menu()
